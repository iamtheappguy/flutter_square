//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<square_in_app_payments/SquareInAppPaymentsFlutterPlugin.h>)
#import <square_in_app_payments/SquareInAppPaymentsFlutterPlugin.h>
#else
@import square_in_app_payments;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [SquareInAppPaymentsFlutterPlugin registerWithRegistrar:[registry registrarForPlugin:@"SquareInAppPaymentsFlutterPlugin"]];
}

@end
